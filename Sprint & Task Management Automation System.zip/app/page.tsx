"use client"

import * as React from "react"
import { ProjectSidebar, type Project } from "@/components/project-sidebar"
import { KanbanBoard, type Column, type Task } from "@/components/kanban-board"
import { AIGenerateButton } from "@/components/ai-generate-button"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Filter, CalendarDays, Users } from "lucide-react"

const projects: Project[] = [
  { id: "1", name: "Website Redesign", color: "bg-blue-500", tasksCount: 12 },
  { id: "2", name: "Mobile App", color: "bg-emerald-500", tasksCount: 8 },
  { id: "3", name: "API Integration", color: "bg-amber-500", tasksCount: 5 },
  { id: "4", name: "Marketing Campaign", color: "bg-rose-500", tasksCount: 15 },
]

const initialColumns: Column[] = [
  {
    id: "todo",
    title: "To Do",
    color: "bg-slate-400",
    tasks: [
      {
        id: "1",
        title: "Design new landing page wireframes",
        description: "Create low-fidelity wireframes for the homepage redesign",
        priority: "high",
        assignee: { name: "Sarah Chen" },
        tags: ["design"],
      },
      {
        id: "2",
        title: "Set up CI/CD pipeline",
        description: "Configure GitHub Actions for automated testing and deployment",
        priority: "medium",
        assignee: { name: "Mike Johnson" },
        tags: ["devops"],
      },
      {
        id: "3",
        title: "Write API documentation",
        priority: "low",
        assignee: { name: "Alex Rivera" },
        tags: ["docs"],
      },
    ],
  },
  {
    id: "in-progress",
    title: "In Progress",
    color: "bg-blue-500",
    tasks: [
      {
        id: "4",
        title: "Implement user authentication",
        description: "Add OAuth2 login with Google and GitHub providers",
        priority: "high",
        assignee: { name: "Emily Watson" },
        tags: ["backend", "security"],
      },
      {
        id: "5",
        title: "Build dashboard components",
        description: "Create reusable chart and metric card components",
        priority: "medium",
        assignee: { name: "John Doe" },
        tags: ["frontend"],
      },
    ],
  },
  {
    id: "review",
    title: "In Review",
    color: "bg-amber-500",
    tasks: [
      {
        id: "6",
        title: "Optimize database queries",
        description: "Improve performance of user listing endpoints",
        priority: "high",
        assignee: { name: "Mike Johnson" },
        tags: ["backend", "performance"],
      },
    ],
  },
  {
    id: "done",
    title: "Done",
    color: "bg-emerald-500",
    tasks: [
      {
        id: "7",
        title: "Setup project repository",
        description: "Initialize Next.js project with TypeScript and Tailwind",
        priority: "medium",
        assignee: { name: "John Doe" },
        tags: ["setup"],
      },
      {
        id: "8",
        title: "Design system foundation",
        description: "Define color palette, typography, and spacing",
        priority: "low",
        assignee: { name: "Sarah Chen" },
        tags: ["design"],
      },
    ],
  },
]

const aiGeneratedTasks: Task[] = [
  {
    id: `ai-${Date.now()}-1`,
    title: "Create user onboarding flow",
    description: "Design and implement a 3-step onboarding wizard for new users",
    priority: "high",
    tags: ["ux", "frontend"],
  },
  {
    id: `ai-${Date.now()}-2`,
    title: "Add email notification system",
    description: "Set up transactional emails for key user actions",
    priority: "medium",
    tags: ["backend", "notifications"],
  },
  {
    id: `ai-${Date.now()}-3`,
    title: "Implement dark mode toggle",
    description: "Add system preference detection and manual toggle",
    priority: "low",
    tags: ["frontend", "accessibility"],
  },
]

export default function SprintDashboard() {
  const [activeProjectId, setActiveProjectId] = React.useState("1")
  const [columns, setColumns] = React.useState<Column[]>(initialColumns)
  const [isGenerating, setIsGenerating] = React.useState(false)
  const [currentSprint, setCurrentSprint] = React.useState("sprint-3")

  const activeProject = projects.find((p) => p.id === activeProjectId)
  
  const totalTasks = columns.reduce((acc, col) => acc + col.tasks.length, 0)
  const completedTasks = columns.find((col) => col.id === "done")?.tasks.length || 0

  const handleAIGenerate = async () => {
    setIsGenerating(true)
    
    // Simulate AI generation delay
    await new Promise((resolve) => setTimeout(resolve, 2000))
    
    // Add AI-generated tasks to the "To Do" column
    const newTasks = aiGeneratedTasks.map((task, index) => ({
      ...task,
      id: `ai-${Date.now()}-${index}`,
    }))

    setColumns((prev) =>
      prev.map((col) =>
        col.id === "todo"
          ? { ...col, tasks: [...newTasks, ...col.tasks] }
          : col
      )
    )
    
    setIsGenerating(false)
  }

  return (
    <div className="flex h-screen bg-background">
      <ProjectSidebar
        projects={projects}
        activeProjectId={activeProjectId}
        onProjectSelect={setActiveProjectId}
      >
        {/* Header content passed as children */}
        <div className="flex flex-1 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className={`h-3 w-3 rounded-sm ${activeProject?.color}`} />
              <h1 className="text-lg font-semibold text-foreground">{activeProject?.name}</h1>
            </div>
            <Badge variant="secondary" className="text-xs font-normal">
              {completedTasks}/{totalTasks} tasks
            </Badge>
          </div>
          
          <div className="flex items-center gap-2">
            <Select value={currentSprint} onValueChange={setCurrentSprint}>
              <SelectTrigger className="w-[140px] h-8 text-xs">
                <CalendarDays className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sprint-1">Sprint 1</SelectItem>
                <SelectItem value="sprint-2">Sprint 2</SelectItem>
                <SelectItem value="sprint-3">Sprint 3</SelectItem>
                <SelectItem value="sprint-4">Sprint 4</SelectItem>
              </SelectContent>
            </Select>
            
            <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5">
              <Filter className="h-3.5 w-3.5" />
              Filter
            </Button>
            
            <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5">
              <Users className="h-3.5 w-3.5" />
              Assignee
            </Button>

            <AIGenerateButton onClick={handleAIGenerate} isLoading={isGenerating} />
          </div>
        </div>
      </ProjectSidebar>

      {/* Main Content - Kanban Board */}
      <main className="flex-1 p-6 overflow-hidden">
        <KanbanBoard columns={columns} onColumnsChange={setColumns} />
      </main>
    </div>
  )
}
