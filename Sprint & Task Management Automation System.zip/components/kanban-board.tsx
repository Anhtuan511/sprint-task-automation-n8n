"use client"

import * as React from "react"
import { MoreHorizontal, Plus, GripVertical } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export type Task = {
  id: string
  title: string
  description?: string
  priority: "low" | "medium" | "high"
  assignee?: {
    name: string
    avatar?: string
  }
  tags?: string[]
}

export type Column = {
  id: string
  title: string
  tasks: Task[]
  color: string
}

interface KanbanBoardProps {
  columns: Column[]
  onColumnsChange?: (columns: Column[]) => void
}

const priorityColors = {
  low: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  medium: "bg-amber-500/10 text-amber-600 border-amber-500/20",
  high: "bg-rose-500/10 text-rose-600 border-rose-500/20",
}

function TaskCard({ task, columnId, onDragStart, onDragEnd }: { 
  task: Task
  columnId: string
  onDragStart: (e: React.DragEvent, taskId: string, columnId: string) => void
  onDragEnd: () => void
}) {
  return (
    <Card
      draggable
      onDragStart={(e) => onDragStart(e, task.id, columnId)}
      onDragEnd={onDragEnd}
      className="group cursor-grab bg-card hover:bg-accent/50 transition-all duration-200 border border-border hover:border-border/80 shadow-sm hover:shadow-md active:cursor-grabbing"
    >
      <CardHeader className="p-3 pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <GripVertical className="h-4 w-4 text-muted-foreground" />
          </div>
          <h4 className="flex-1 font-medium text-sm leading-tight text-foreground">{task.title}</h4>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity">
                <MoreHorizontal className="h-3.5 w-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuItem>Edit</DropdownMenuItem>
              <DropdownMenuItem>Move to...</DropdownMenuItem>
              <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="p-3 pt-0">
        {task.description && (
          <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{task.description}</p>
        )}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 flex-wrap">
            <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 font-medium", priorityColors[task.priority])}>
              {task.priority}
            </Badge>
            {task.tags?.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-[10px] px-1.5 py-0 bg-secondary/50">
                {tag}
              </Badge>
            ))}
          </div>
          {task.assignee && (
            <Avatar className="h-6 w-6 border-2 border-background">
              <AvatarImage src={task.assignee.avatar} alt={task.assignee.name} />
              <AvatarFallback className="text-[10px] bg-primary text-primary-foreground">
                {task.assignee.name.split(" ").map((n) => n[0]).join("")}
              </AvatarFallback>
            </Avatar>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

function KanbanColumn({ 
  column, 
  onDragOver, 
  onDrop, 
  onDragStart,
  onDragEnd,
  isDragOver 
}: { 
  column: Column
  onDragOver: (e: React.DragEvent) => void
  onDrop: (e: React.DragEvent, columnId: string) => void
  onDragStart: (e: React.DragEvent, taskId: string, columnId: string) => void
  onDragEnd: () => void
  isDragOver: boolean
}) {
  return (
    <div 
      className="flex flex-col min-w-[300px] max-w-[320px] flex-shrink-0"
      onDragOver={onDragOver}
      onDrop={(e) => onDrop(e, column.id)}
    >
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <div className={cn("w-2.5 h-2.5 rounded-full", column.color)} />
          <h3 className="font-semibold text-sm text-foreground">{column.title}</h3>
          <span className="text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded-full font-medium">
            {column.tasks.length}
          </span>
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div 
        className={cn(
          "flex flex-col gap-2.5 p-2 rounded-lg bg-muted/30 min-h-[500px] transition-colors duration-200",
          isDragOver && "bg-muted/60 ring-2 ring-primary/20"
        )}
      >
        {column.tasks.map((task) => (
          <TaskCard 
            key={task.id} 
            task={task} 
            columnId={column.id}
            onDragStart={onDragStart}
            onDragEnd={onDragEnd}
          />
        ))}
      </div>
    </div>
  )
}

export function KanbanBoard({ columns: initialColumns, onColumnsChange }: KanbanBoardProps) {
  const [columns, setColumns] = React.useState<Column[]>(initialColumns)
  const [draggedTask, setDraggedTask] = React.useState<{ taskId: string; sourceColumnId: string } | null>(null)
  const [dragOverColumn, setDragOverColumn] = React.useState<string | null>(null)

  React.useEffect(() => {
    setColumns(initialColumns)
  }, [initialColumns])

  const handleDragStart = (e: React.DragEvent, taskId: string, columnId: string) => {
    setDraggedTask({ taskId, sourceColumnId: columnId })
    e.dataTransfer.effectAllowed = "move"
  }

  const handleDragEnd = () => {
    setDraggedTask(null)
    setDragOverColumn(null)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = "move"
  }

  const handleDrop = (e: React.DragEvent, targetColumnId: string) => {
    e.preventDefault()
    if (!draggedTask || draggedTask.sourceColumnId === targetColumnId) {
      setDragOverColumn(null)
      return
    }

    const newColumns = columns.map((col) => {
      if (col.id === draggedTask.sourceColumnId) {
        return {
          ...col,
          tasks: col.tasks.filter((t) => t.id !== draggedTask.taskId),
        }
      }
      if (col.id === targetColumnId) {
        const sourceColumn = columns.find((c) => c.id === draggedTask.sourceColumnId)
        const task = sourceColumn?.tasks.find((t) => t.id === draggedTask.taskId)
        if (task) {
          return {
            ...col,
            tasks: [...col.tasks, task],
          }
        }
      }
      return col
    })

    setColumns(newColumns)
    onColumnsChange?.(newColumns)
    setDraggedTask(null)
    setDragOverColumn(null)
  }

  return (
    <div className="flex gap-4 overflow-x-auto pb-4 px-1">
      {columns.map((column) => (
        <KanbanColumn
          key={column.id}
          column={column}
          onDragOver={(e) => {
            handleDragOver(e)
            setDragOverColumn(column.id)
          }}
          onDrop={handleDrop}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
          isDragOver={dragOverColumn === column.id && draggedTask?.sourceColumnId !== column.id}
        />
      ))}
    </div>
  )
}
